#ifndef _LOG_H_
#define _LOG_H_

#include <stdio.h>

#ifdef ENABLE_DEBUG_LOG
#define ALOGV(fmt, ...) printf("VERBOS: " fmt "\n", ##__VA_ARGS__)
#define ALOGD(fmt, ...) printf("DEBUG: " fmt "\n", ##__VA_ARGS__)
#else
#define ALOGV(fmt, ...)
#define ALOGD(fmt, ...)
#endif

#define ALOGI(fmt, ...) printf("INFO: " fmt "\n", ##__VA_ARGS__)
#define ALOGW(fmt, ...) printf("WARNING: " fmt "\n", ##__VA_ARGS__)
#define ALOGE(fmt, ...) printf("ERROR: " fmt "\n", ##__VA_ARGS__)

#endif
