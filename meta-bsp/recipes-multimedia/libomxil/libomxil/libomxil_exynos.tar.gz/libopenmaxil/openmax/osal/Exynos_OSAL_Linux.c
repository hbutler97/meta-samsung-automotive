/*
 * Copyright 2016 Samsung Electronics S.LSI Co. LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file        Exynos_OSAL_Linux.c
 * @brief
 * @author      Taehwan Kim (t_h.kim@samsung.com)
 * @version     1.0.0
 * @history
 *   2016.06.13 : Create
 */

#include <stdio.h>
#include <stdlib.h>

#include "Exynos_OSAL_Semaphore.h"
#include "Exynos_OMX_Baseport.h"
#include "Exynos_OMX_Basecomponent.h"
#include "Exynos_OMX_Macros.h"
#include "Exynos_OSAL_Platform.h"
#include "Exynos_OSAL_ETC.h"
#include "exynos_format.h"

#include "ExynosVideoApi.h"

#define EXYNOS_LOG_TAG    "Exynos_OSAL_Linux"
//#define EXYNOS_LOG_OFF
#include "Exynos_OSAL_Log.h"

#ifdef __cplusplus
extern "C" {
#endif

static OMX_ERRORTYPE setBufferProcessTypeForDecoder(EXYNOS_OMX_BASEPORT *pExynosPort)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    FunctionIn();

    if (pExynosPort == NULL) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        ret = OMX_ErrorUndefined;
        goto EXIT;
    }

    if ((pExynosPort->bufferProcessType == BUFFER_COPY) &&
        (pExynosPort->eMetaDataType != METADATA_TYPE_DISABLED)) {
        int i;
        if (pExynosPort->supportFormat == NULL) {
            ret = OMX_ErrorUndefined;
            Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] supported format is empty", __FUNCTION__);
            goto EXIT;
        }

        pExynosPort->portDefinition.format.video.eColorFormat = OMX_COLOR_FormatYUV420SemiPlanar;
        /* check to support NV12T format */
        for (i = 0; pExynosPort->supportFormat[i] != OMX_COLOR_FormatUnused; i++) {
            /* prefer to use NV12T */
            if (pExynosPort->supportFormat[i] == (OMX_COLOR_FORMATTYPE)OMX_SEC_COLOR_FormatNV12Tiled) {
                pExynosPort->portDefinition.format.video.eColorFormat = (OMX_COLOR_FORMATTYPE)OMX_SEC_COLOR_FormatNV12Tiled;
                break;
            }
        }
        pExynosPort->bufferProcessType = BUFFER_SHARE;

        Exynos_OSAL_Log(EXYNOS_LOG_ESSENTIAL, "[%s] output buffer sharing mode is on (%x)",
                                                __FUNCTION__, pExynosPort->portDefinition.format.video.eColorFormat);
    }

EXIT:
    FunctionOut();

    return ret;
}

static void resetBufferProcessTypeForDecoder(EXYNOS_OMX_BASEPORT *pExynosPort)
{
    FunctionIn();

    if (pExynosPort == NULL) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        goto EXIT;
    }

    pExynosPort->bufferProcessType = BUFFER_COPY;
    pExynosPort->portDefinition.format.video.eColorFormat = OMX_COLOR_FormatYUV420Planar;

EXIT:
    FunctionOut();

    return;
}

OMX_ERRORTYPE Exynos_OSAL_GetParameter(
    OMX_IN OMX_HANDLETYPE hComponent,
    OMX_IN OMX_INDEXTYPE  nIndex,
    OMX_INOUT OMX_PTR     pComponentParameterStructure)
{
    OMX_ERRORTYPE                ret                = OMX_ErrorNone;
    OMX_COMPONENTTYPE           *pOMXComponent      = NULL;
    EXYNOS_OMX_BASECOMPONENT    *pExynosComponent   = NULL;

    FunctionIn();

    if (hComponent == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    pOMXComponent = (OMX_COMPONENTTYPE *)hComponent;
    ret = Exynos_OMX_Check_SizeVersion(pOMXComponent, sizeof(OMX_COMPONENTTYPE));
    if (ret != OMX_ErrorNone)
        goto EXIT;

    if (pOMXComponent->pComponentPrivate == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    pExynosComponent = (EXYNOS_OMX_BASECOMPONENT *)pOMXComponent->pComponentPrivate;
    if (pExynosComponent->currentState == OMX_StateInvalid) {
        ret = OMX_ErrorInvalidState;
        goto EXIT;
    }

    if (pComponentParameterStructure == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    switch ((int)nIndex) {
    case OMX_IndexParamPortDefinition:
    {
        OMX_PARAM_PORTDEFINITIONTYPE    *pPortDef       = (OMX_PARAM_PORTDEFINITIONTYPE *)pComponentParameterStructure;
        EXYNOS_OMX_BASEPORT             *pExynosPort    = &pExynosComponent->pExynosPort[pPortDef->nPortIndex];

        if (pExynosPort->eMetaDataType == METADATA_TYPE_DATA)
            pPortDef->nBufferSize = MAX_METADATA_BUFFER_SIZE;
    }
        break;
    default:
    {
        ret = OMX_ErrorUnsupportedIndex;
        goto EXIT;
    }
        break;
    }

EXIT:
    FunctionOut();

    return ret;
}

OMX_ERRORTYPE Exynos_OSAL_SetParameter(
    OMX_IN OMX_HANDLETYPE hComponent,
    OMX_IN OMX_INDEXTYPE  nIndex,
    OMX_IN OMX_PTR        pComponentParameterStructure)
{
    OMX_ERRORTYPE                ret                = OMX_ErrorNone;
    OMX_COMPONENTTYPE           *pOMXComponent      = NULL;
    EXYNOS_OMX_BASECOMPONENT    *pExynosComponent   = NULL;

    FunctionIn();

    if (hComponent == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    pOMXComponent = (OMX_COMPONENTTYPE *)hComponent;
    ret = Exynos_OMX_Check_SizeVersion(pOMXComponent, sizeof(OMX_COMPONENTTYPE));
    if (ret != OMX_ErrorNone)
        goto EXIT;

    if (pOMXComponent->pComponentPrivate == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    pExynosComponent = (EXYNOS_OMX_BASECOMPONENT *)pOMXComponent->pComponentPrivate;
    if (pExynosComponent->currentState == OMX_StateInvalid) {
        ret = OMX_ErrorInvalidState;
        goto EXIT;
    }

    if (pComponentParameterStructure == NULL) {
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    Exynos_OSAL_Log(EXYNOS_LOG_ESSENTIAL, "[%p][%s] index = 0x%x", pExynosComponent, __FUNCTION__, nIndex);
    switch ((int)nIndex) {
    case OMX_IndexParamStoreMetaDataBuffer:
    {
        ret = OMX_ErrorNotImplemented;
    }
        break;
    default:
    {
        ret = OMX_ErrorUnsupportedIndex;
        goto EXIT;
    }
        break;
    }

EXIT:
    FunctionOut();

    return ret;
}

#ifdef USE_STOREMETADATA
/*
 * meta data contains the following data format.
 * 1) METADATA_TYPE_DATA
 * --------------------------------------------------------------------
 * | MMVideoBuffer                                                    | [DEC] out, [ENC] in
 * --------------------------------------------------------------------
 */
OMX_ERRORTYPE Exynos_OSAL_LockMetaData(
    OMX_IN OMX_PTR                          pBuffer,
    OMX_IN EXYNOS_OMX_LOCK_RANGE            range,
    OMX_OUT OMX_U32                        *pStride,
    OMX_OUT EXYNOS_OMX_MULTIPLANE_BUFFER   *pBufferInfo,
    OMX_IN EXYNOS_METADATA_TYPE             eMetaType)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    FunctionIn();

    if (pBuffer == NULL) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    /* not used yet */

EXIT:
    FunctionOut();

    return ret;
}

OMX_ERRORTYPE Exynos_OSAL_UnlockMetaData(
    OMX_IN OMX_PTR              pBuffer,
    OMX_IN EXYNOS_METADATA_TYPE eMetaType)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    FunctionIn();

    if (pBuffer == NULL) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    /* not used yet */

EXIT:
    FunctionOut();

    return ret;
}

OMX_ERRORTYPE Exynos_OSAL_GetInfoFromMetaData(
    OMX_IN OMX_PTR                          pBuffer,
    OMX_OUT EXYNOS_OMX_MULTIPLANE_BUFFER   *pBufferInfo,
    OMX_IN EXYNOS_METADATA_TYPE             eMetaDataType)
{
    OMX_ERRORTYPE    ret            = OMX_ErrorNone;

    int i;

    FunctionIn();

    if ((pBuffer == NULL) ||
        (pBufferInfo == NULL) ||
        (eMetaDataType == METADATA_TYPE_DISABLED)) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] not implemented yet(meta type:0x%x)", __FUNCTION__, eMetaDataType);
    ret = OMX_ErrorNotImplemented;

EXIT:
    FunctionOut();

    return ret;
}

OMX_ERRORTYPE Exynos_OSAL_SetDataLengthToMetaData(
    OMX_IN OMX_BYTE             pBuffer,
    OMX_IN OMX_U32              dataLength,
    OMX_IN EXYNOS_METADATA_TYPE eMetaDataType)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    FunctionIn();

    if (pBuffer == NULL) {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] invalid parameter", __FUNCTION__);
        ret = OMX_ErrorBadParameter;
        goto EXIT;
    }

    /* not used yet */
    /* This is for that MetaData is configured by component */

EXIT:
    FunctionOut();

    return ret;
}

OMX_PTR Exynos_OSAL_AllocMetaDataBuffer(
    OMX_HANDLETYPE          hSharedMemory,
    EXYNOS_METADATA_TYPE    eMetaDataType,
    OMX_U32                 nSizeBytes,
    MEMORY_TYPE             eMemoryType)
{
    OMX_PTR pBuffer = NULL;

    FunctionIn();

    if (eMetaDataType == METADATA_TYPE_DATA) {
        pBuffer = Exynos_OSAL_Malloc(sizeof(MAX_METADATA_BUFFER_SIZE));
        if (pBuffer == NULL) {
            Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] Failed to allocate metadata buffer", __FUNCTION__);
            goto EXIT;
        }
    } else {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] not implemented yet(meta type:0x%x)", __FUNCTION__, eMetaDataType);
    }

EXIT:
    FunctionOut();

    return pBuffer;
}

OMX_ERRORTYPE Exynos_OSAL_FreeMetaDataBuffer(
    OMX_HANDLETYPE          hSharedMemory,
    EXYNOS_METADATA_TYPE    eMetaDataType,
    OMX_PTR                 pTempBuffer)
{
    OMX_ERRORTYPE ret = OMX_ErrorNone;

    FunctionIn();

    if (eMetaDataType == METADATA_TYPE_DATA) {
        Exynos_OSAL_Free(pTempBuffer);
        ret = OMX_ErrorNone;
    } else {
        Exynos_OSAL_Log(EXYNOS_LOG_ERROR, "[%s] not implemented yet(meta type:0x%x)", __FUNCTION__, eMetaDataType);
        ret = OMX_ErrorNotImplemented;
        goto EXIT;
    }
EXIT:
    FunctionOut();

    return ret;
}
#endif

#ifdef __cplusplus
}
#endif
